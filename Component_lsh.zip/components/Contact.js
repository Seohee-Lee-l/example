function Contact() {
    return (
        <div id='main'>
            <h2>Contact Page</h2>
            <p>React - CONTACT PAGE</p>

            <div id='img'>
                <img src='img/05.jpg' alt='img'/>
                <img src='img/06.jpg' alt='img'/>
                <img src='img/07.jpg' alt='img'/>
                <img src='img/08.jpg' alt='img'/>
            </div>
        </div>
    );
}
windoow.Contact=Contact;