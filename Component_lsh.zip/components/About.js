function About() {
    return (
        <div id='main'>
            <h2>About Page</h2>
            <p>React - ABOUT PAGE</p>

            <div id='img'>
                <img src='img/01.jpg' alt='img'/>
                <img src='img/02.jpg' alt='img'/>
                <img src='img/03.jpg' alt='img'/>
                <img src='img/04.jpg' alt='img'/>
            </div>
        </div>
    );
}
window.About=About;