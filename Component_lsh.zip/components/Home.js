function Home() {
    return (
        <div id='main'>
            <h2>Home Page</h2>
            <p>React - HOME PAGE</p>

            <div id='img'>
                <img src='img/07.jpg' alt='img'/>
            </div>
        </div>
    );
}
window.Home=Home;