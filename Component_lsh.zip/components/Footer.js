function Footer() {
    return (
        <footer>
            <h2>Footer Page</h2>

            <p>React - FOOTER PAGE</p>

            <div id='img'>
                <img src='img/05.jpg' alt='img'/>
                <img src='img/06.jpg' alt='img'/>
            </div>
        </footer>
    );
}
window.Footer=Footer;