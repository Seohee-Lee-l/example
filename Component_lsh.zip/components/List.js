function List() {
    return (
        <div id='main'>
            <h2>List Page</h2>
            <p>React - LIST PAGE</p>

            <p>IMAGE LIST</p>
            <div id='img'>
                <img src='img/09.jpg' alt='img'/>
                <img src='img/10.jpg' alt='img'/>
                <img src='img/11.jpg' alt='img'/>
                <img src='img/12.jpg' alt='img'/>

                <img src='img/01.jpg' alt='img'/>
                <img src='img/02.jpg' alt='img'/>
                <img src='img/03.jpg' alt='img'/>
                <img src='img/04.jpg' alt='img'/>
            </div>
        </div>
    );
}
window.List=List;