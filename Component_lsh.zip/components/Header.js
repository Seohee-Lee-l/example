function Header() {
    return (
        <header>
            <h1>
                <a href='index.html'>
                    Component Web
                </a>
            </h1>
        </header>
    );
}
window.Header=Header;