$(function() {
    let lastScrollTop=0;
    const delta=5;
    const $fixBox=$(".bottomNav");
    const fixBoxHeight=$fixBox.outerHeight();
    let didScroll=false;
    // 스크롤이 발생했는 지를 표시하는 플래그


    // 스크롤 이벤트 발생 시 플래그 변경
    $(window).on("scroll", function() {
        didScroll=true;
    });


    // 250ms마다 스크롤 감지
    setInterval(function() {
        if (didScroll) {
            hasScrolled();
            didScroll=false;
            // didScroll을 false로 리셋
        }
    }, 250);


    function hasScrolled() {
        const nowScrollTop=$(this).scrollTop();
        // 현재 스크롤 위치

        if (Math.abs(lastScrollTop - nowScrollTop) <= delta) {
            return;
            // 스크롤 차이가 delta(5) 이하라면 아무 작업도 하지 않음
        }

        if (nowScrollTop > lastScrollTop && nowScrollTop > fixBoxHeight) {
            $fixBox.removeClass("show");
        } else {
            if (nowScrollTop + $(window).height() < $(document).height())
                // 페이지 끝에 도달하지 않았다면 bottomNav 보여줌
            // 위로 스크롤 중 & 문서 끝에 도달하지 않으면 bottomNav 보여줌
                {
                $fixBox.addClass("show");
            }
        }

        lastScrollTop=nowScrollTop;
        // 현재 스크롤 위치를 마지막 스크롤 위치로 저장
    };
});