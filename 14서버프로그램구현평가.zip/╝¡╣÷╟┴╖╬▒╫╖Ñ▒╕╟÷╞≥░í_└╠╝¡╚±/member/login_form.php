<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mobile_login</title>

    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/01.css">
    <link rel="stylesheet" href="xeicon/css/xeicon.min.css">
    <script src="js/jquery-1.11.2.min.js"></script>
</head>



<body>
    
    <header id="header">
        <h2><a href="index.html" class="logo">Moogo</a></h2>

        <form action="#" class="search">
            <input type="text" placeholder="Movie name / Director / Country / Genre ...">
            <button type="submit"><i class="xi-search"></i></button>
        </form>

        <div class="category">
            <ul>
                <li><a href="#" id="menu-btn">Menu</a></li>
                <li><a href="request.html">Request</a></li>
                <!-- <li><a href="login.html">Login</a></li> -->
                <li> <? include "top_login1.php"; ?> </li>
            </ul>
        </div>
    </header>

    <section class="login">
        <h2>Login</h2>        
        
        <form action="login.php" class="login-form" method="post" name='member_form'>
            <label for=id">Username or E-mail</label>
            <input type="text" name="id" id="id" required placeholder="id">

            <label for="pass">Password</label>
            <input type="password" id="pass" name="pass" required placeholder="Enter your password">

            <button type="submit">Log in</button>
        </form>
        
        <ul>
            <li><a href="#">Find your username</a></li>
            <li><a href="#">Find your password</a></li>
            <li><a href="member_conditions.html">Sign up</a></li>
        </ul>
    </section>
</body>


</html>