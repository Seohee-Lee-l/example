<?
    session_start();
?>

<!doctype html>
<html lang='ko'>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>html</title>

    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/01.css">
    <link rel="stylesheet" href="xeicon/css/xeicon.min.css">
    <script src="js/jquery-1.11.2.min.js"></script>

    <script>
        function check_id() {
            window.open("check_id.php?id=" + document.member_form.id.value,
                "IDcheck",
                "left=200, top=200, width=200, height=100, scrollbars=no, resizable=yes");
        }

        function check_email() {
            window.open("check_email.php?email=" + document.member_form.email.value, 
                "EMAILcheck",
                "left=200, top=200, width=300, height=100, scrollbars=no, resizable=yes");
        }

        function check_input() {
            const re1=/^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$/;
            const id=document.member_form.id.value;
            if (!document.member_form.id.value) {
                alert("아이디를 입력하세요");
                document.member_form.id.focus();
                return;
            } else if (!re1.test(id)) {
                alert("6~10자의 영문자,숫자,특수기호 혼합해서 사용할 수 있습니다");
                return false;
            }

            if (!document.member_form.pass.value) {
                alert("비밀번호를 입력하세요");
                document.member_form.pass.focus();
                return;
            }

            if (!document.member_form.pass_confirm.value) {
                alert("비밀번호 확인을 입력하세요");
                document.member_form.pass_confirm.focus();
                return;
            }

            if (!document.member_form.name.value) {
                alert("이름을 입력하세요");
                document.member_form.name.focus();
                return;
            }

            if (!document.member_form.hp.value) {
                alert("휴대폰 번호를 입력하세요");
                document.member_form.hp.focus();
                return;
            }

            if (!document.member_form.email.value) {
                alert("이메일 주소를 입력하세요");
                document.member_form.email.focus();
                return;
            }

            if (document.member_form.pass.value != document.member_form.pass_confirm.value) {
                alert("비밀번호가 일치하지 않습니다. \n 다시 입력해주세요");
                document.member_form.pass.focus();
                document.member_form.pass.select();
                return;
            }

            const hp1=document.member_form.hp.value;
            const re2=/^01([0|1|6|7|8|9])-?([0-9]{3,4})-?([0-9]{4})$/;

            if (!re2.test(hp1)) {
                alert("휴대폰 번호를 다시 입력해주세요");
                return false;
            }

            const email=document.member_form.email.value;
            const re3=/^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/;

            if (!re3.test(email)) {
                alert("@를 포함해서 입력해주세요");
                return false;
            }

            document.member_form.submit();
        }        
        
        function reset_form() {
            document.member_form.id.value="";
            document.member_form.pass.value="";
            document.member_form.pass_confirm.value="";
            document.member_form.name.value="";
            document.member_form.hp.value="";
            document.member_form.email.value="";
            document.member_form.id.focus();

            return;
        }
    </script>
</head>

<body>
    <header id="header">
        <h2><a href="index.html" class="logo">Moogo</a></h2>

        <form action="#" class="search">
            <input type="text" placeholder="Movie name / Director / Country / Genre ...">
            <button type="submit"><i class="xi-search"></i></button>
        </form>

        <div class="category">
            <ul>
                <li><a href="#" id="menu-btn">Menu</a></li>
                <li><a href="request.html">Request</a></li>
                <!-- <li><a href="login.html">Login</a></li> -->
                <li> <? include "top_login1.php"; ?> </li>
            </ul>
        </div>
    </header>    
    
    <div id="signup">
        <h2>회원가입</h2>

        <div id='join_mem'>
            <form name='member_form' method='post' action='insert.php'>
                <div id='form_join'>
                    <div id='join1'>
                        <ul>
                            <li>아이디</li>
                            <li>비밀번호</li>
                            <li>비밀번호 확인</li>
                            <li>이름</li>
                            <li>휴대폰</li>
                            <li>이메일</li>
                        </ul>
                    </div>

                    <div id='joni2'>
                        <ul>
                            <li>
                                <div id='id1'>
                                    <input type="text" name='id' id='id' placeholder='6-10자 영문자, 숫자, 특수기호 혼합' required minlength='6' maxlength='10'>
                                </div>

                                <div id='id2'>
                                    <p onclick='check_id()' class='id-button'>중복 확인</p>
                                </div>
                            </li>

                            <li>
                                <input type="password" name='pass' id='pass' placeholder='비밀번호 입력' required>
                            </li>

                            <li>
                                <input type="password" name='pass_confirm' id='pass_confirm' placeholder='비밀번호 확인' required>
                            </li>

                            <li>
                                <input type="text" name='name' id='name' placeholder='이름 입력' required>
                            </li>

                            <li>
                                <input type="tel" class='hp' name='hp' id='hp' placeholder='01012345678' required>
                            </li>

                            <li>
                                <div id='email1'>
                                    <input type="email" name='email' id='email' placeholder='ab123@gmail.com' required>
                                </div>

                                <div id='email2'>
                                    <p onclick='check_email()' id='email-button'>중복 확인</p>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div class='clear'></div>
                    <div id='must'>*는 필수 입력 항목입니다</div>
                </div>

                <div id='button'>
                    <p onclick="check_input()">가입하기</p>
                    <p onclick="reset_form()">전체 지우기</p>
                </div>
            </form>
        </div>
    </div>
</body>