<?
    session_start();
?>

<div id='top_login'>

<?
    if(!$_SESSION['username'] )
    {
?>

    <a href="login_form.php">Login</a>
<?
    }
    else
    {
?>
    <span><?=$_SESSION['userid']?></span>
    <a href="logout.php" class='logout'>Logout</a>
<?
    }
?>

</div>