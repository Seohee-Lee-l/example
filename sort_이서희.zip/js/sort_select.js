$(function() {

    $(".sort select").on("change", function() {
        const ab=$(this).val();
        const $lis=$(".content ul > li");

        const n=ab.substr(4, 1);

        const sort=$lis.sort(function(a, b) {
            if (n==0) {
                location.reload(true);
            } else if (n==1) {
                return new Date($(a).find("p.date").text()) > new Date($(b).find("p.date").text()) ? -1
                : new Date($(a).find("p.date").text()) < new Date($(b).find("p.date").text()) ? 1
                : 0;
            } else if (n==2) {
                return new Date($(a).find("p.date").text()) < new Date($(b).find("p.date").text()) ? -1
                : new Date($(a).find("p.date").text()) > new Date($(b).find("p.date").text()) ? 1
                : 0;
            } else if (n==3) {
                return parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) > parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? -1
                : parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) < parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? 1
                : 0;
            } else if (n==4) {
                return parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) < parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? -1
                : parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) > parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? 1
                : 0;
            } else if (n==5) {
                return $(a).find("p.name a").text() < $(b).find("p.name a").text() ? -1
                : $(a).find("p.name a").text() > $(b).find("p.name a").text() ? 1
                : 0;
            }
        });

        $(".item").html(sort);
    });
});