$(function() {
    // $(".search ul li").on("click", function(e) {
    //     e.preventDefault();

    //     const a=$(this).attr("class");
    //     const result=a.substr(4, 1);

    //     const sort=$("#content ul li").sort(function(a, b) {
    //         if (result==0) {
    //             return new Date($(a).find("span.date").text()) > new Date($(b).find("span.date").text()) ? -1
    //             : new Date($(a).find("span.date").text()) < new Date($(b).find("span.date").text()) ? 1
    //             : 0;
    //         } else if (result==1) {
    //             return parseInt($(a).find("span.price").text().replace(/[^0-9]/g, '')) > parseInt($(b).find("span.price").text().replace(/[^0-9]/g, '')) ? -1
    //             : parseInt($(a).find("span.price").text().replace(/[^0-9]/g, '')) < parseInt($(b).find("span.price").text().replace(/[^0-9]/g, '')) ? 1
    //             : 0;
    //         } else {
    //             return parseInt($(a).find("span.price").text().replace(/[^0-9]/g, '')) < parseInt($(b).find("span.price").text().replace(/[^0-9]/g, '')) ? -1
    //             : parseInt($(a).find("span.price").text().replace(/[^0-9]/g, '')) > parseInt($(b).find("span.price").text().replace(/[^0-9]/g, '')) ? 1
    //             : 0;
    //         }
    //     });
       
    //     $("#content ul").html(sort);

    // });


    $(".sort ul li").on('click', function(e) {
        e.preventDefault();

        const a=$(this).attr("class");
        const result=a.substr(4, 1);

        const sort=$(".content ul li").sort(function(a, b) {
            if (result==0) {
                return new Date($(a).find("p.date").text()) > new Date($(b).find("p.date").text()) ? -1
                : new Date($(a).find("p.date").text()) < new Date($(b).find("p.date").text()) ? 1
                : 0;
            } else if (result==1) {
                return new Date($(a).find("p.date").text()) < new Date($(b).find("p.date").text()) ? -1
                : new Date($(a).find("p.date").text()) > new Date($(b).find("p.date").text()) ? 1
                : 0;
            } else if (result==2) {
                return parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) > parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? -1
                : parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) < parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? 1
                : 0;
            } else if (result==3) {
                return parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) < parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? -1
                : parseInt($(a).find("p.price").text().replace(/[^0-9]/g, '')) > parseInt($(b).find("p.price").text().replace(/[^0-9]/g, '')) ? 1
                : 0;
            } else if (result==4) {
                return $(a).find("p.name a").text() < $(b).find("p.name a").text() ? -1
                : $(a).find("p.name a").text() > $(b).find("p.name a").text() ? 1
                : 0;
            }
        });
        $(".item").html(sort);
    });
});