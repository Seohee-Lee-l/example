$(function() {
    $(".slider").slick({
        autoplaySpeed: 2000,
        autoplay: true,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 2,
        dots: true,
        responsive: [
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $("select.select").on("change", function() {
        const ab = $(this).val();
        slideTarget(ab.substr(4, 1));

        function slideTarget(n) {
            if (n == 0) {
                $(".slider").slick('slickUnfilter');
            } else if (n == 1) {
                $(".slider").slick('slickUnfilter');
                $(".slider").slick('slickFilter', $(".slider li").filter(".espresso"));
            } else if (n == 2) {
                $(".slider").slick("slickUnfilter");
                $(".slider").slick("slickFilter", $(".slider li").filter(".coldbrew"));
            } else if (n == 3) {
                $(".slider").slick("slickUnfilter");
                $(".slider").slick("slickFilter", $(".slider li").filter(".bread"));
            } else {
                $(".slider").slick("slickUnfilter");
                $(".slider").slick("slickFilter", $(".slider li").filter(".cake"));
            }
        }
    });
});