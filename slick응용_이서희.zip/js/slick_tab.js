$(function() {
    $(".slider").slick({
        autoplaySpeed: 2000,
        autoplay: true,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 2,
        dots: true,
        responsive: [
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $(".slick-buttons a").on("click", function(e) {
        const n=$(this).index();

        if (n==0) {
            $(".slider").slick("slickUnfilter");
        } else if (n==1) {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".espresso"));
        } else if (n==2) {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".coldbrew"));
        } else if (n==3) {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".bread"));
        } else {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".cake"));
        }

        e.preventDefault();
    });
});