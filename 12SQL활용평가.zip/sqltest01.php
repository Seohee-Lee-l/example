<?php
    // MySQL 데이터베이스에 연결 (호스트, 사용자, 비밀번호, DB명)
    $connect=mysqli_connect("localhost", "sag1880", "seo30513!!", "sag1880") or die ("SQL server에 연결할 수 없습니다.");

    // sqltest01 테이블의 모든 데이터를 선택하는 SQL 쿼리 작성
    $sql="SELECT * FROM sqltest01";
    // SQL 쿼리를 실행하고 결과를 $result에 저장
    $result=mysqli_query($connect, $sql);

    // 쿼리 실행이 성공했는지 확인
    if ($result) {
        // 테이블 시작 및 테이블 헤더 출력
        echo "<table border='1'>";
        echo "<tr><td>직원번호</td>
              <td>구분코드</td>
              <td>종류</td>
              <td>교육월수</td>
              <td>연수비</td>
              </tr>";

        // 결과 집합에서 한 행씩 데이터를 가져와서 출력
        while ($row=mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>".$row['bunho']."</td>";
            echo "<td>".$row['code']."</td>";
            echo "<td>".$row['sort']."</td>";
            echo "<td>".$row['mon']."</td>";
            echo "<td>".$row['price']."</td>";
            echo "</tr>";
        }
        // 테이블 종료
        echo "</table>";
    } else {
        // 쿼리 실패 시 에러 메시지 출력
        echo "쿼리 실패: ".mysqli_error($connect);
    }

    // 데이터베이스 연결 종료
    mysqli_close($connect);
?>