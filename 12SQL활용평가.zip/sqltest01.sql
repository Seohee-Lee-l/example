create table sqltest01 (
    bunho varchar(4),
    code varchar(1),
    sort varchar(3),
    mon int,
    price int,
    primary key(bunho)
)