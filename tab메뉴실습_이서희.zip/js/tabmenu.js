$(function() {


    // tab 메뉴
    $(".selected-section:not("+$(".quick-menu ul li a.selected").attr("href")+")").hide();

    $(".quick-menu ul li a").click(function() {
        $(".quick-menu ul li a").removeClass("selected");
        $(this).addClass("selected");

        $(".selected-section").hide();
        $($(this).attr("href")).show();

        return false;
    });




    // 메뉴
    $("#menu-btn").click(function() {
    if ($("#nav-menu").is(":animated")) {
        return false;
    }
    
    const currentRight = $("#nav-menu").css("right");
    const currentTop = $("#nav-menu").css("top");

    if (window.innerWidth <= 1200) {
        if (currentRight === "0px") {
            $("#nav-menu").animate({ right: "-80%" }, 500);
        } else {
            $("#nav-menu").animate({ right: "0" }, 500);
        }
    } else {
        if (currentTop === "60px") {
            $("#nav-menu").animate({ top: "-60%" }, 500);
        } else {
            $("#nav-menu").animate({ top: "60px" }, 500);
        }
    }
    });


    // 메뉴 닫기(x 버튼)
    $("#close-menu-btn").on("click", function() {
        $("#nav-menu").animate({right: "-80%"}, 500);
    });



    // 서브 메뉴
    $(".menu-title").click(function(e) {
        e.preventDefault();

        if (window.innerWidth<=1200) {
            if ($(this).next().is(":visible"))
        {
            $(this).next().stop().slideUp(300);
            $(this).children("i").attr("class", "xi-plus-thin");
        } else {
            $(".sub-menu").stop().slideUp(300);
            $(".menu-title").children("i").attr("class", "xi-plus-thin");

            $(this).next().stop().slideDown(300);
            $(this).children("i").attr("class", "xi-minus-thin");
        };
        };
        
    });


    // 검색창
    let isOpen=false;
    $("#search-btn").click(function() {
        if (!isOpen) {
            $(".search-pop-down").stop().animate({top: "60px"}, 700);
        } else {
            $(".search-pop-down").stop().animate({top:"-60%"}, 700);
        }
        isOpen=!isOpen;
    });



    // 제품 페이지 - 옵션
    $("#filter-btn").click(function(e) {
        e.preventDefault();

        if ($(this).next().is(":visible"))
        {
            $(this).next().stop().css("display", "none");
        } else {
            $(this).next().css("display", "block");
        }
    });

    $("#sort-btn").click(function(e) {
        e.preventDefault();

        if ($(this).next().is(":visible"))
        {
            $(this).next().stop().css("display", "none");
        } else {
            $(this).next().css("display", "block");
        }
    });



    // 제품 판매 페이지 - 상세 보기
    $(".ex_click").click(function() {
        if ($(this).next().is(":visible"))
        {
            $(this).next().stop().slideUp(500);
        } else {
            $(this).next().slideDown(500)
        };
    });




    const $mainImage=$(".item-page > .slideShow");
	const $imgs=$mainImage.find("img");

	let currentIndex=0;
	const totalSlides=$imgs.length;
	let autoSlideInterval;



	// slideTo() 함수
	function slideTo(index) {
		if (index < 0) index=0;
		if (index>=totalSlides) index=totalSlides-1;

		$imgs.removeClass("active").eq(index).addClass("active");

		currentIndex=index;
	};


	// startAutoSlide() 함수
	function startAutoSlide() {
		autoSlideInterval=setInterval(function() {
			let nextIndex=(currentIndex+1)%totalSlides;

			slideTo(nextIndex);
		}, 4000);
	};

    $(window).on("resize", function() {
		slideTo(currentIndex);
	});

    slideTo(0);
    startAutoSlide();




    // 메인 배너 슬라이드
    const $ul=$("#main_image ul");
    const $slide=$ul.find("li");
    const $bookRoll=$("#book_roll li a");

    let curIndex=0;
    const totalSlide=$slide.length;
    let interval;

    function slideto(index) {
        curIndex=index;
        if (curIndex>=totalSlide) curIndex=0;
        if (curIndex<0) curIndex=totalSlide-1;

        $ul.css("transform", `translateX(${-100*curIndex}%)`);
        updateIndicators();
    }

    function updateIndicators() {
        $bookRoll.each(function(i) {
            const img=$(this).find("img");
            if (i===curIndex) {
                img.attr("src", "img/indicator_on.png");
            } else {
                img.attr("src", "img/indicator_out.png");
            }
        });
    };

    function startSlide() {
        clearInterval(interval);
        interval=setInterval(() => {
            slideto(curIndex+1);
        }, 3000);
    };


    $bookRoll.each(function(i) {
        $(this).on("click", function(e) {
            e.preventDefault();

            slideto(i);
            startSlide();
        });
    });

    $(window).on("resize", function() {
        slideto(curIndex);
    });

    slideto(0);
    startSlide();




    // pc 배너 이미지 변경
    function updateImages() {
        const isPc=$(window).width() >= 1200;
        $("#main_image ul li img").each(function() {
            const $img=$(this);
            const pcSrc=$img.data("pc");
            const mobileSrc=$img.data("mobile");

            if (isPc && pcSrc) {
                $img.attr("src", pcSrc);
            } else if (mobileSrc) {
                $img.attr("src", mobileSrc);
            }
        });
    }


    $(window).on("resize", function() {
            updateImages();
			slideto(curIndex);
		});
});    


document.addEventListener('DOMContentLoaded', function() { 
    const option = document.querySelector('.pc-option');
    const footer = document.querySelector('footer');

    window.addEventListener('scroll', () => {
    const optionHeight = option.offsetHeight;
    const footerTop = footer.getBoundingClientRect().top + window.scrollY;

    const maxTop = footerTop - optionHeight;

    if (window.scrollY < maxTop) {
        option.style.top = '0px'; // normal fixed 위치
    } else {
        option.style.top = `${maxTop - window.scrollY}px`;
    }
    });

    

    const slides = document.querySelectorAll(".item-img img");
    const prevBtn = document.querySelector(".prev");
    const nextBtn = document.querySelector(".next");
    const bars = document.querySelectorAll(".nav .bar");
    const slideContainer = document.querySelector(".item-img");

    let currentIndex = 0;

    function showSlide(index) {
    if (index >= slides.length) currentIndex = 0;
    else if (index < 0) currentIndex = slides.length - 1;
    else currentIndex = index;

    const offset = -currentIndex * 100;
    slideContainer.style.transform = `translateX(${offset}%)`;

    bars.forEach(bar => bar.classList.remove("active"));
    bars[currentIndex].classList.add("active");
    }

    prevBtn.addEventListener("click", () => showSlide(currentIndex - 1));
    nextBtn.addEventListener("click", () => showSlide(currentIndex + 1));

    bars.forEach((bar, idx) => {
    bar.addEventListener("click", () => showSlide(idx));
    });

    showSlide(0);



    // let fadeShow=document.querySelector(".fadeShow");
    // let imgs=fadeShow.querySelectorAll('img');
    // let currentIndex2=0;

    // imgs[currentIndex2].classList.add("active");

    // function fadeInOut() {
    //     let currentImg=imgs[currentIndex2];
    //     let nextIndex=(currentIndex2+1)%imgs.length;
    //     let nextImg=imgs[nextIndex];

    //     nextImg.classList.add("active");
    //     currentImg.classList.remove("active");

    //     currentIndex2=nextIndex;
    // };
    // setInterval(fadeInOut, 3000);


    let fadeShows=document.querySelectorAll(".fadeShow");

    fadeShows.forEach(fadeShow=> {
        let imgs=fadeShow.querySelectorAll("img");
        let currentIndex2=0;

        imgs[currentIndex2].classList.add("acrive");

        function fadeInOut() {
            let currentImg=imgs[currentIndex2];
            let nextIndex=(currentIndex2+1)%imgs.length;
            let nextImg=imgs[nextIndex];

            nextImg.classList.add("active");
            currentImg.classList.remove("active");

            currentIndex2=nextIndex;
        }
        setInterval(fadeInOut, 3000);
    });


    const items=document.querySelectorAll('.item');
    items.forEach(item=> {
        const minus=item.querySelector('.minus');
        const plus=item.querySelector(".plus");
        const count=item.querySelector(".count");
        const deleteBtn=item.querySelector(".delete");
        const addCartBtn=item.querySelector(".add-cart");

        let num=parseInt(count.textContent);

        minus.addEventListener("click", function() {
            if (num>1) count.textContent=--num;
        });

        plus.addEventListener('click', function() {
            count.textContent=++num;
        });
    });

    const countBoxes=document.querySelectorAll(".count-box");
    countBoxes.forEach(box=> {
        const minus=box.querySelector(".minus");
        const plus=box.querySelector(".plus");
        const count=box.querySelector(".count");

        let num=parseInt(count.textContent);

        minus.addEventListener("click", function() {
            if (num>1) count.textContent=--num;
        });

        plus.addEventListener("click", function() {
            count.textContent=++num;
        });
    });

});