
$(function () {
    const $items=$(".coffee-list li");
    const totalItems=$items.length;
    let visibleCount=0;

    function getShow() {
        const winWidth=$(window).width();

        if (winWidth <= 600) {
            return 2;
        } else if (winWidth <= 800) {
            return 3;
        } else {
            return 4;
        }
    }


    function update(countToShow) {
        $items.hide();
        $items.slice(0, countToShow).show();

        if (countToShow >= totalItems) {
            $(".more_btn").hide();
        } else {
            $(".more_btn").show();
        }
    }


    function initializeList() {
        const showCount=getShow();

        visibleCount=Math.max(visibleCount, showCount);
        update(visibleCount);
    }

    initializeList();


    $(".more_btn").on("click", function() {
        const showCount=getShow();
        visibleCount+=showCount;

        if (visibleCount > totalItems) {
            visibleCount=totalItems;
        }

        update(visibleCount);
    });

    $(window).on("resize", function() {
        initializeList();
    });
});