create table book (
    book varchar(20),
    customer varchar(12),
    ordercode varchar(10),
    price int,
    count int,
    totalprice int,
    primary key(ordercode)
);