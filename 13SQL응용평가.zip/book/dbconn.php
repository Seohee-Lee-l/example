<?php
    $connect=mysqli_connect("localhost", "sag1880", "seo30513!!", "sag1880") or die ("SQL server에 연결할 수 없습니다.");
?>