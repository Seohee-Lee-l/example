<meta charset="UTF-8">

<?php
    include "dbconn.php";    $book=$_POST['book'];
    
    $book=$_POST['book'];
    $customer=$_POST['customer'];
    $ordercode=$_POST['ordercode'];
    $price=$_POST['price'];
    $count=$_POST['count'];

    $sql="insert into book(book, customer, ordercode, price, count) values";
    $sql.="('$book', '$customer', '$ordercode', '$price', '$count')";
    
    $result=mysqli_query($connect, $sql);

    mysqli_close($connect);

    echo "
        <script>
            location.href='book_list.php';
        </script>
    ";
?>