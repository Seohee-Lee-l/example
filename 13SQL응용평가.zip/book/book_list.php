<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <style>
        h3 {
            text-align: center;
        }

        table {
            padding: 20px;
            box-sizing: border-box;
            margin: 0 auto;
        }
        
        tr, td {
            border: none;
            text-align: center;
        }

        p {
            text-align: center;
        }
    </style>
</head>

<body>
    <h3>도서 구매 이용자 목록</h3>

    <form action="book_insert.php" method='post'>
        <table width='1000' border='1'>
            <tr>
                <td>도서명 : <input type="text" size='20' name='book' ></td>
                <td>구매자 : <input type="text" size='12' name='customer'></td>
                <td>주문번호 : <input type="text" size='10' name='ordercode'></td>
                <td>가격 : <input type="text" size='10' name='price'></td>
                <td>수량 : <input type="text" size='3' name='count'></td>
                <td><input type="submit" value='입력'></td>
            </tr>
        </table>
    </form>

    <div>
        <h3>도서 구매 이용자</h3>

        <p>
            <a href="book_list.php?mode=big_first">[주문번호 내림차순 정렬]</a>
            <a href="book_list.php?mode=small_first">[주문번호 오름차순 정렬]</a>
        </p>
    </div>
    
    <table width='1000' border='1'>
        <tr>
            <td>도서명</td>
            <td>구매자</td>
            <td>주문번호</td>
            <td>가격</td>
            <td>수량</td>
            <td>주문 금액</td>
            <td>삭제</td>
        </tr>

        <?php
            include "dbconn.php";

            $mode=$_GET['mode'];

            $bookname=$_POST['book'];
            $customer=$_POST['customer'];
            $ordercode=$_POST['ordercode'];
            $price=$_POST['price'];
            $count=$_POST['count'];


            if ($mode=="big_first")
                $sql="select * from book order by ordercode desc";
            else if ($mode=="small_first")
                $sql="select * from book order by ordercode";
            else
                $sql="select * from book";        $result=mysqli_query($connect, $sql);

            while ($row=mysqli_fetch_array($result)) {
                $ordercode=$row['ordercode'];
                $totalprice = $row['price'] * $row['count']; // PHP로 계산

                echo "
                    <tr>
                        <td>$row[book]</td>
                        <td>$row[customer]</td>
                        <td>$row[ordercode]</td>
                        <td>$row[price]</td>
                        <td>$row[count]</td>
                        <td>$totalprice</td>
                        <td><a href='book_del.php?ordercode=$ordercode'>[삭제]</a></td>
                    </tr>
                ";
            }

            mysqli_close($connect);
        ?>
    </table>
</body>

</html>