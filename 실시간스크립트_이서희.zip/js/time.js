$(function() {
    const ticker=function() {
        setTimeout(function() {
            $("#ticker li:first").animate({marginTop: "-20px"}, 400, function() {
                $(this).detach().appendTo("ul#ticker").removeAttr("style");
            });
            ticker();
        }, 3000);
    };

    ticker();
});