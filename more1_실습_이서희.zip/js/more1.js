
$(function () {
    function listMore() {
        const $items = $(".coffee-list li");
        const totalItems = $items.length;
        let showCount = 0;

        const winWidth=$(window).width();

        if (winWidth <= 600) {
            showCount = 2;
        } else if (winWidth <= 800) {
            showCount = 3;
        } else {
            showCount = 4;
        }


        $items.hide();
        $items.slice(0, showCount).show();


        $(".more_btn button").off("click").on("click", function() {
            let visibleCount=$(".coffee-list li:visible").length;

            let nextCount=visibleCount+showCount;

            if (nextCount > totalItems) nextCount=totalItems;

            $items.slice(0, nextCount).show();


            if (nextCount===totalItems) {
                $(".more_btn").hide();
            }
        });



        if (showCount < totalItems) {
            $(".more_btn").show();
        } else {
            $(".more_btn").hide();
        }

    }   

    listMore();



    $(window).on("resize", function() {
        listMore();
    });
});