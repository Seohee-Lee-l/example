<?php
    include "dbconn.php";

    $ordercode=$_GET['ordercode'];

    $sql="delete from book where ordercode='$ordercode'";

    mysqli_query($connect, $sql);
    mysqli_close($connect);

    Header("Location:book_list.php");
?>